#include "canif.h"
#include "can.h"
#include <stdio.h>
#include <string.h>

/* ===== Callback nhận dữ liệu từ tầng CanIf (App tự định nghĩa) ===== */
void App_RxCallback(uint32_t RxPduId, uint8_t* data, uint8_t len)
{
    printf("App nhận frame: RxPduId = %lu, len = %d, data: ", RxPduId, len);
    for (uint8_t i = 0; i < len; ++i)
        printf("%02X ", data[i]);
    printf("\n");
}

/* ===== Callback xác nhận truyền (nếu cần) ===== */
void App_TxConfirm(uint32_t TxPduId)
{
    printf("App xác nhận đã gửi thành công: TxPduId = %lu\n", TxPduId);
}

/* ===== Cấu hình CanIf_ConfigType demo ===== */
CanIf_ConfigType myCanIfConfig = {
    .numControllers = 1,
    .defaultControllerMode = {CANIF_CONTROLLER_STARTED},
    .numTxPdus = 1,
    .defaultTxPduMode = {CANIF_ONLINE},
    .numRxPdus = 1,
    .defaultRxPduMode = {CANIF_ONLINE},
    .numRoutingEntry = 2,
    .routingTable = {
        {0, 0x321, 1}, // TxPduId 0 → CAN ID 0x321 (TX)
        {0, 0x123, 2}  // RxPduId 0 → CAN ID 0x123 (RX)
    },
    .txConfirmation = App_TxConfirm, // callback xác nhận gửi (tùy dùng)
    .rxIndication   = App_RxCallback // callback nhận dữ liệu
};

/* ====== (Nếu muốn cấu hình timing/baudrate cho driver, bạn có thể khai báo như sau) ====== */
Can_ConfigType myCanHwConfig = {
    .CAN_Prescaler = 6,            // ví dụ cho 500kbps (tùy clock, bạn điều chỉnh)
    .CAN_Mode = CAN_Mode_Normal,
    .CAN_SJW = CAN_SJW_1tq,
    .CAN_BS1 = CAN_BS1_8tq,
    .CAN_BS2 = CAN_BS2_1tq,
    .FilterIdHigh = 0x0000,
    .FilterIdLow = 0x0000,
    .FilterMaskIdHigh = 0x0000,
    .FilterMaskIdLow = 0x0000,
};

int main(void)
{
    // ===== Init UART hoặc retarget printf nếu muốn xuất log =====
    // UART_Init(); // Tùy vào platform, bạn bổ sung nếu dùng log qua UART

    // ===== 1. Init hardware CAN driver =====
    Can_Init(&myCanHwConfig);

    // ===== 2. Init CanIf với config đã chuẩn bị =====
    CanIf_Init(&myCanIfConfig);

    // ===== 3. Vòng lặp ứng dụng =====
    printf("CAN test bắt đầu!\n");

    // ===== Gửi thử một frame CAN (TxPduId=0) lên CAN bus =====
    uint8_t demoData[8] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};
    CanIf_Transmit(0, demoData, 8);

    while (1)
    {
        // Không cần code xử lý nhận ở đây, 
        // Khi có data CAN, driver sẽ tự động gọi callback CanIf_RxIndication,
        // và callback này báo lên App_RxCallback để xử lý.

        // ===== Nếu muốn tự test mô phỏng nhận data (không có hardware): =====
        // uint8_t fakeRx[8] = {1,2,3,4,5,6,7,8};
        // CanIf_RxIndication(0x123, fakeRx, 8); // mapping với RxPduId = 0

        // delay nhỏ, tránh spam (nếu không có RTOS)
        for (volatile int i = 0; i < 1000000; ++i);
    }
}
